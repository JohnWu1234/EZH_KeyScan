/*
 * @brief IOH Architecture B mnemonics
 *
 * @note
 * Copyright(C) NXP Semiconductors, 2014
 * All rights reserved.
 *
 * @par
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * LPC products.  This software is supplied "AS IS" without any warranties of
 * any kind, and NXP Semiconductors and its licensor disclaim any and
 * all warranties, express or implied, including all implied warranties of
 * merchantability, fitness for a particular purpose and non-infringement of
 * intellectual property rights.  NXP Semiconductors assumes no responsibility
 * or liability for the use of the software, conveys no license or rights under any
 * patent, copyright, mask work right, or any other intellectual property rights in
 * or to any products. NXP Semiconductors reserves the right to make changes
 * in the software without notification. NXP Semiconductors also makes no
 * representation or warranty that such application will be suitable for the
 * specified use without further testing or modification.
 *
 * @par
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, under NXP Semiconductors' and its
 * licensor's relevant copyrights in the software, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 */

#include "fsl_ezhb.h"
#include "fsl_ezhb_isr.h"
#include "fsl_debug_console.h"
#include "ezh_key_scan.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* LPC51U68 */
#define EZH_BREAKADDR              0x1D030
#define EZH_BREAKVECT              0x1D034
#define EZH_EMERVECT               0x1D038
#define EZH_EMERSEL                0x1D03C
#define EZH_ARM2EZH                0x1D040
#define EZH_EZH2ARM                0x1D044 

#define EZH_CODE	__attribute__((section("EZH_SECT"))) 

#define KEY_ROW_1      5
#define KEY_ROW_2      18
#define KEY_ROW_3      7
#define KEY_ROW_4      21
#define KEY_ROW_5      6

#define KEY_COLUMN_1   8
#define KEY_COLUMN_2   9
#define KEY_COLUMN_3   10
#define KEY_COLUMN_4   31
#define KEY_COLUMN_5   2

#define PINFUNC_EZH		4//12
#define PINFUNC_GPIO	0

#define NEED_DELAY	1
#define time_delay_us 100 * 96 // first factor is time you need set, the maximum is 680us under 96MHz.
  
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
extern EZH_KeyScan_queue queue_1;
extern EZH_KeyScan_Para para;

volatile uint32_t keyvalue[64];
extern unsigned int key_value[5];
/*******************************************************************************
 * Code
 ******************************************************************************/
/* Active key scan when key row and colume > 8 */

__asm void EZH_CODE EZH_KeyScan(void)
{
    E_NOP
    E_PER_READ(R6, EZH_ARM2EZH)
    E_LSR(R6, R6, 2)
    E_LSL(R6, R6, 2)
    E_LDR(SP, R6, 0)
	  E_LDR(R7, R6, 1) // R7 -> BUFFER
//	  E_LDR(R6, R6, 2) // R6 -> POS ADDRESS
//	  E_XOR(R4, R4, R4) // R4 = POS
	
    /* Set all row as low */
    E_BCLR_IMM(GPO, GPO, KEY_ROW_1)
    E_BCLR_IMM(GPO, GPO, KEY_ROW_2)
    E_BCLR_IMM(GPO, GPO, KEY_ROW_3)
    E_BCLR_IMM(GPO, GPO, KEY_ROW_4)
		E_BCLR_IMM(GPO, GPO, KEY_ROW_5)//2019

    /* Set all row as output */
    E_BSET_IMM(GPD, GPD, KEY_ROW_1)
    E_BSET_IMM(GPD, GPD, KEY_ROW_2)
    E_BSET_IMM(GPD, GPD, KEY_ROW_3)
    E_BSET_IMM(GPD, GPD, KEY_ROW_4)
		E_BSET_IMM(GPD, GPD, KEY_ROW_5)//2019
		
    /* Set all column as input */
    E_BCLR_IMM(GPD, GPD, KEY_COLUMN_1)
    E_BCLR_IMM(GPD, GPD, KEY_COLUMN_2)
    E_BCLR_IMM(GPD, GPD, KEY_COLUMN_3)
    E_BCLR_IMM(GPD, GPD, KEY_COLUMN_4)
		E_BCLR_IMM(GPD, GPD, KEY_COLUMN_5)//2019
		
		E_HEART_RYTHM_IMM(9600)

kdown /* start detect key*/
    E_LOAD_IMM(R0, 0)
		E_LOAD_IMM(R1, 0)
		E_LOAD_IMM(R2, 0)
		E_LOAD_IMM(R3, 0)
		E_LOAD_IMM(R4, 0)
		
    E_LOAD_IMM(R5, 1)
		

    /* Scan 1st row */
    E_BCLR_IMM(GPO, GPO, KEY_ROW_1)
#if NEED_DELAY
		E_WAIT_FOR_BEAT
#endif
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_1)
    E_COND_OR(ZE, R0, R0, R5) /* bit 0 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_2)
    E_COND_LSL_OR(ZE, R0, R0, R5, 1) /* bit 1 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_3)
    E_COND_LSL_OR(ZE, R0, R0, R5, 2) /* bit 2 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_4)
    E_COND_LSL_OR(ZE, R0, R0, R5, 3) /* bit 3 */
		E_BTST_IMMS(GPI, GPI, KEY_COLUMN_5)//2019
    E_COND_LSL_OR(ZE, R0, R0, R5, 4) /* bit 4 *///2019
		
    E_BSET_IMM(GPO, GPO, KEY_ROW_1)
		/* Scan 2nd row */		
    E_BCLR_IMM(GPO, GPO, KEY_ROW_2)		
#if NEED_DELAY
		E_WAIT_FOR_BEAT
#endif	
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_1)
    E_COND_OR(ZE, R1, R1, R5) /* bit 0 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_2)
    E_COND_LSL_OR(ZE, R1, R1, R5, 1) /* bit 1 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_3)
    E_COND_LSL_OR(ZE, R1, R1, R5, 2) /* bit 2 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_4)
    E_COND_LSL_OR(ZE, R1, R1, R5, 3) /* bit 3 */
		E_BTST_IMMS(GPI, GPI, KEY_COLUMN_5)
    E_COND_LSL_OR(ZE, R1, R1, R5, 4) /* bit 4 */

    E_BSET_IMM(GPO, GPO, KEY_ROW_2)
		/* Scan 3rd row */		
    E_BCLR_IMM(GPO, GPO, KEY_ROW_3)
#if NEED_DELAY
		E_WAIT_FOR_BEAT
#endif
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_1)
    E_COND_OR(ZE, R2, R2, R5) /* bit 0 */	
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_2)
    E_COND_LSL_OR(ZE, R2, R2, R5, 1) /* bit 1 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_3)
    E_COND_LSL_OR(ZE, R2, R2, R5, 2) /* bit 2 */	
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_4)
    E_COND_LSL_OR(ZE, R2, R2, R5, 3) /* bit 3 */
		E_BTST_IMMS(GPI, GPI, KEY_COLUMN_5)
    E_COND_LSL_OR(ZE, R2, R2, R5, 4) /* bit 4 */

    E_BSET_IMM(GPO, GPO, KEY_ROW_3)	
		/* Scan 4th row */		
    E_BCLR_IMM(GPO, GPO, KEY_ROW_4)	
#if NEED_DELAY
		E_WAIT_FOR_BEAT
#endif	
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_1)
    E_COND_OR(ZE, R3, R3, R5) /* bit 0 */	
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_2)
    E_COND_LSL_OR(ZE, R3, R3, R5, 1) /* bit 1 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_3)
    E_COND_LSL_OR(ZE, R3, R3, R5, 2) /* bit 2 */	
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_4)
    E_COND_LSL_OR(ZE, R3, R3, R5, 3) /* bit 3 */
		E_BTST_IMMS(GPI, GPI, KEY_COLUMN_5)
    E_COND_LSL_OR(ZE, R3, R3, R5, 4) /* bit 4 */
		
    E_BSET_IMM(GPO, GPO, KEY_ROW_4)

		/* Scan 5th row */		
    E_BCLR_IMM(GPO, GPO, KEY_ROW_5)	
#if NEED_DELAY
		E_WAIT_FOR_BEAT
#endif
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_1)
    E_COND_OR(ZE, R4, R4, R5) /* bit 0 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_2)
    E_COND_LSL_OR(ZE, R4, R4, R5, 1) /* bit 1 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_3)
    E_COND_LSL_OR(ZE, R4, R4, R5, 2) /* bit 2 */
    E_BTST_IMMS(GPI, GPI, KEY_COLUMN_4)
    E_COND_LSL_OR(ZE, R4, R4, R5, 3) /* bit 3 */
		E_BTST_IMMS(GPI, GPI, KEY_COLUMN_5)
    E_COND_LSL_OR(ZE, R4, R4, R5, 4) /* bit 4 */

    E_BSET_IMM(GPO, GPO, KEY_ROW_5)	


		E_COND_GOTO(EX, kdown)//if ex == 1 return to kdown
		
		E_LDR(R5, R7, 0)//R7 address's memory save to R5
		E_LDR(R6, R7, 1)//R7 address+1's memory save to R6
		E_XORS(R5, R0, R5)//R0 Key value xor to R5, and update flag
		E_COND_GOTO(NZ, diff)
		
		E_LDR(R5, R7, 2)//R7 address+2's memory save to R5, because R5 was release
		E_XORS(R6, R1, R6)//R1 Key value xor to R6, and update flag
		E_COND_GOTO(NZ, diff)
		
		E_LDR(R6, R7, 3)//R7 address+3's memory save to R6, because R5 was release
		E_XORS(R5, R2, R5)//R2 Key value xor to R5, and update flag
		E_COND_GOTO(NZ, diff)
		
		E_LDR(R5, R7, 4)//R7 address+2's memory save to R5, because R5 was release
		E_XORS(R6, R3, R6)//R3 Key value xor to R6, and update flag
		E_COND_GOTO(NZ, diff)
		
		E_XORS(R5, R4, R5)//R4 Key value xor to R6, and update flag
		E_COND_GOTO(ZE, kdown)//if all key value are same value back to key down

//ts
//    E_GOTO(ts)	
	
diff
		E_STR(R7, R0, 0)//if NZ R0's value save to R7 address's memory
		E_STR(R7, R1, 1)//if NZ R1's value save to R7 address+1's memory
		E_STR(R7, R2, 2)//if NZ R2's value save to R7 address+2's memory
		E_STR(R7, R3, 3)//if NZ R3's value save to R7 address+3's memory
		E_STR(R7, R4, 4)//if NZ R4's value save to R7 address+4's memory
		
		
to_int
    E_INT_TRIGGER(1234)									// notify app to update next foreground buffer address and fill count
		E_GOTO(kdown)		
}

void IOH_IRQHandler(){
	EZH_SetExternalFlag(1) ;
	PRINTF("\r\n");
	
	
//		PRINTF("queue_1.ezh_write: 0x%x \r\n",queue_1.ezh_write);

	PRINTF("r0: 0x%x \r\n",key_value[0]);
	PRINTF("r1: 0x%x \r\n",key_value[1]);
	PRINTF("r2: 0x%x \r\n",key_value[2]);
	PRINTF("r3: 0x%x \r\n",key_value[3]);
	PRINTF("r4: 0x%x \r\n",key_value[4]);
	
	EZH_SetExternalFlag(0) ;
}



void EZH_INT_Init(void){
		NVIC_EnableIRQ(IOH_IRQn);
}
void EZH_Pin_Init(void){
	// >>> configure pins
	IOCON->PIO[0][KEY_ROW_1] 			= PINFUNC_EZH | 1<<7 | 1<<8;
	IOCON->PIO[0][KEY_ROW_2]			= PINFUNC_EZH | 1<<7 | 1<<8;
	IOCON->PIO[0][KEY_ROW_3] 			= PINFUNC_EZH | 1<<7 | 1<<8;
	IOCON->PIO[0][KEY_ROW_4] 			= PINFUNC_EZH | 1<<7 | 1<<8;
	IOCON->PIO[0][KEY_ROW_5] 			= PINFUNC_EZH | 1<<7 | 1<<8;
//	IOCON->PIO[0][KEY_COLUMN_1]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
//	IOCON->PIO[0][KEY_COLUMN_2]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
//	IOCON->PIO[0][KEY_COLUMN_3]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
//	IOCON->PIO[0][KEY_COLUMN_4]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
	IOCON->PIO[0][KEY_COLUMN_1]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
	IOCON->PIO[0][KEY_COLUMN_2]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
	IOCON->PIO[0][KEY_COLUMN_3]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
	IOCON->PIO[0][KEY_COLUMN_4]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
	IOCON->PIO[0][KEY_COLUMN_5]		= PINFUNC_EZH | 2<<3 | 1<<7 | 1<<8; //pull up enable
	
	queue_1.read  = 0;
	queue_1.write = 0;	
	queue_1.ezh_write = 0;	
	for(int i = 0 ;i < 64; i++ ){
		keyvalue[i] = 0;
	}
	
}

